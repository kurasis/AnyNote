# AnyNote offline reviewer handoff

Software source: c52af68046f98e55fab904f2f9bfd3984e54498a
Immutable original report archive: 5df3aa7c85fabad8c5b36a2502f733bd0aa47351
https://github.com/kurasis/AnyNote/tree/5df3aa7c85fabad8c5b36a2502f733bd0aa47351/docs/evidence/windows-memory/final

This local-only handoff retains155 API-digest-verified original ZIPs across six
cohorts, including the original failures/cancellations, both final PR/main review
sets (Windows/PWA/API), exact public source, original CI Git objects and the
immutable original-report archive. No candidates are rebuilt or re-signed.
No runtime SQL/volumes, user kits, TLS/OAuth/signing credentials or profiles are
selected. The original API candidate includes the already evaluated synthetic
container image. Review artifacts and test signatures are not production releases.

Before running any received code, independently establish its trusted origin.
Retain the external manifest and archive SHA-256 values through a trusted channel.
Use the trusted external verifier with Python3.12 or later:

    python3 release-handoff-verify.py HANDOFF.tar.gz --manifest-sha256 TRUSTED_SHA256

It streams all members without extracting/executing them and requires exact
names/counts/lengths/digests. A checksum next to an attacker-controlled download
does not authenticate the publisher. This package is not an independent audit.
The source bundle can populate a separate reviewer repository for original Git
blob verification. The original API ZIP metadata/receipt remains beside every ZIP;
the upstream Actions attachments expire14days after upload, whereas this complete
offline copy does not depend on attachment retention.

## Work requiring external capability or owner decision

| Gate | Required input and result | Current status |
| --- | --- | --- |
| Independent review | Appointed qualified reviewer; protocol/crypto/auth/recovery/update findings, remediation/retest, scoped disposition | NOT_RUN; no outreach/bookings |
| Physical iPhone | Known iPhone17Pro/iOS26.7.1 plus supported-range scope; trusted HTTPS host, real1GB Files/lifecycle/PRF/memory evidence | NOT_RUN; trusted private host not ready |
| Physical Windows | Windows11Pro25H2/Hello/TPM, lock/session/suspend, physical memory observations | NOT_RUN; hosted Windows is separate |
| Real100GB | Isolated sized host with actual ciphertext plus backup/work/reserve inventory | BLOCKED here; filesystem is smaller than the100GB payload |
| Signing and custody | Real Authenticode/updater identities; independent final-byte verification and separated recovery/backup/static deployment custody | NOT_RUN; no real keys collected or generated |
| License and operations | Repository-wide release-license decision, named operator/custodians and actual acceptance | OWNER_DECISION_REQUIRED; Windows derivative GPL-3.0-only |
| Production publication | Separate authorization after the above, fresh exact final artifacts and checks | BLOCKED; no deployment or GitHub Release |

The original hosted memory failure is resolved only for the independently checked
PR/main sampled native/helper1GB scope (89608192/95379456B against134217728B).
Physical/unsampled bounds remain open. Generic candidate CLI output intentionally
retains RETEST_REQUIRED until complete exact-cohort assembly; review-main/acceptance.json
records the resolved hosted software gate. Neither route opens production.

After physical/independent/signing evidence arrives, preserve originals, bind it to
the precise source/artifact bytes and record actual outcomes. Do not edit old
reports or use new signatures/issuers with stale acceptance. Reuse the source
runbooks P17_SECURITY_REVIEW, P18_RELEASE, P16_OPERATIONS and OPERATOR_HANDOFF.
Owner Review/Save then Publish activates the saved cloud draft; this local handoff
does not prove snapshot publication or restoration on another machine.
