#!/usr/bin/env python3
"""Check a local handoff as a bounded stream; never extract or execute members."""
import argparse
import hashlib
import json
from pathlib import PurePosixPath
import tarfile

MAX_TOTAL = 8 * 1024**3
MAX_MEMBER = 2 * 1024**3


def require(value, message):
    if not value:
        raise ValueError(message)


def safe(name):
    require(isinstance(name, str) and name and '\\' not in name, 'Invalid member path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(s not in ('', '.', '..') for s in name.split('/')),
            'Unsafe member path')
    require(all(ord(c) >= 32 and ord(c) != 127 and c != ':' for c in name),
            'Unsafe cross-platform path')
    return name


def verify(path, expected_manifest_sha256):
    require(len(expected_manifest_sha256) == 64 and
            all(c in '0123456789abcdef' for c in expected_manifest_sha256),
            'An independently retained manifest SHA-256 is required')
    observed = {}; folded = set(); total = 0; manifest = None
    with tarfile.open(path, mode='r|gz') as archive:
        for index, member in enumerate(archive):
            require(index < 5000 and member.isreg() and not member.pax_headers and
                    not member.sparse, 'Only bounded regular members are admitted')
            name = safe(member.name)
            require(name not in observed and name.casefold() not in folded,
                    'Duplicate or case-colliding member')
            folded.add(name.casefold())
            require(0 <= member.size <= MAX_MEMBER, 'Member size limit')
            total += member.size; require(total <= MAX_TOTAL, 'Total size limit')
            stream = archive.extractfile(member); digest = hashlib.sha256(); size = 0
            manifest_data = bytearray() if index == 0 else None
            if index == 0:
                require(name == 'manifest.json' and member.size <= 2 * 1024**2,
                        'Bounded manifest must be the first member')
            while chunk := stream.read(1024 * 1024):
                size += len(chunk); digest.update(chunk)
                if manifest_data is not None:
                    manifest_data.extend(chunk)
            require(size == member.size, 'Truncated member')
            if index == 0:
                require(digest.hexdigest() == expected_manifest_sha256,
                        'Manifest does not match the independently retained checksum')
                manifest = json.loads(manifest_data)
                require(manifest['schema'] == 'anynote-offline-review-handoff-v1' and
                        manifest['production_release_allowed'] is False,
                        'Wrong schema or production scope')
            else:
                observed[name] = {'bytes': size, 'sha256': digest.hexdigest()}
    require(manifest is not None, 'Missing manifest')
    expected = {}
    for row in manifest['files']:
        name = safe(row['path'])
        require(name not in expected and name != 'manifest.json', 'Duplicate manifest path')
        expected[name] = {'bytes': row['bytes'], 'sha256': row['sha256']}
    require(observed == expected and observed, 'Missing, extra, modified or mis-sized file')
    return {'status': 'PASS', 'files': len(observed), 'payload_bytes': total,
            'manifest_sha256': expected_manifest_sha256,
            'source_commit': manifest['source_commit'],
            'evidence_commit': manifest['evidence_commit'],
            'members_extracted_or_executed': False,
            'scope': 'Byte consistency against the supplied external checksum; not publisher identity or independent review'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive'); p.add_argument('--manifest-sha256', required=True)
    args = p.parse_args()
    print(json.dumps(verify(args.archive, args.manifest_sha256), indent=2))
