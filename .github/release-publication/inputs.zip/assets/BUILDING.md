# Rebuild the Windows release profile

This delivery preserves the exact existing tested main build. It does not bump
the native application version, introduce production signing or grant release eligibility.
Windows binary: 0.14.0. Review-set version: 0.18.0-review.

Use Windows x64, Rust 1.99.0 MSVC, Node 24.21.0/npm 11.19.0, Python 3.12,
Microsoft C++ Build Tools/Windows SDK and WebView2. From the exact source tree:

```powershell
rustup override set 1.99.0
if ($LASTEXITCODE -ne 0) { throw 'Pinned Rust activation failed' }
foreach ($project in @('packages/protocol','experiments/p01','packages/api-client','packages/content-browser','apps/devices-web','apps/notes-web','apps/desktop')) {
  npm --prefix $project ci --ignore-scripts --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw 'Frozen installation failed' }
}
node experiments/p01/node_modules/esbuild/install.js
if ($LASTEXITCODE -ne 0) { throw 'Build prerequisite failed' }
node apps/desktop/node_modules/esbuild/install.js
if ($LASTEXITCODE -ne 0) { throw 'Build prerequisite failed' }
python apps/desktop/prepare-runtime.py
if ($LASTEXITCODE -ne 0) { throw 'Build prerequisite failed' }
python scripts/p14-dependencies.py --stage
if ($LASTEXITCODE -ne 0) { throw 'Build prerequisite failed' }
python scripts/check-p14.py
if ($LASTEXITCODE -ne 0) { throw 'Build prerequisite failed' }
cargo test --manifest-path packages/windows-native/Cargo.toml --locked -j 4 -- --test-threads=1
if ($LASTEXITCODE -ne 0) { throw 'Native custody tests failed' }
npm --prefix apps/desktop run tauri -- build --ci -- --locked -j 4
if ($LASTEXITCODE -ne 0) { throw 'Release profile build failed' }
```

The installer is under `apps/desktop/src-tauri/target/release/bundle/nsis`.
Do not enable `integration-harness` in a user installer. `--ci` selects noninteractive
Tauri build behavior; it does not enable that Rust feature. Do not replace a new
installer's evidence with receipts for the bytes in this delivery. Production
Authenticode/updater signing and independent final-byte verification remain separate.
