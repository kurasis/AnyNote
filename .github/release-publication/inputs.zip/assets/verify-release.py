#!/usr/bin/env python3
"""Verify an unpacked delivery before deployment; never execute delivered programs."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


def require(value, message):
    if not value:
        raise ValueError(message)


def verify(directory):
    root = Path(directory).resolve(strict=True)
    manifest_file = root / 'release-manifest.json'
    require(manifest_file.is_file() and not manifest_file.is_symlink(), 'Regular manifest required')
    checksum_file = root / 'MANIFEST.sha256'
    require(checksum_file.is_file() and not checksum_file.is_symlink(), 'Regular checksum file required')
    expected_manifest_sha = checksum_file.read_text().strip().split()[0]
    raw = manifest_file.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == expected_manifest_sha, 'Manifest checksum mismatch')
    manifest = json.loads(raw)
    require(manifest['schema'] == 'anynote-release-delivery-v1' and
            manifest['production_release_allowed'] is False, 'Unknown delivery scope')
    require(0 < len(manifest['files']) <= 5000, 'Unexpected file count')
    expected = set(); folded = set(); total = 0
    for row in manifest['files']:
        name = row['path']; parts = name.split('/'); path = PurePosixPath(name)
        require(name and '\\' not in name and not path.is_absolute() and
                all(p not in ('', '.', '..') for p in parts), 'Unsafe path')
        require(all(ord(c) >= 32 and ord(c) != 127 and c != ':' for c in name), 'Unsafe path characters')
        require(name not in expected and name.casefold() not in folded, 'Duplicate path')
        expected.add(name); folded.add(name.casefold())
        file = root.joinpath(*parts)
        require(file.is_file() and all(not p.is_symlink() for p in [file, *file.parents] if p != root.parent),
                'Missing or linked file: ' + name)
        require(file.resolve().is_relative_to(root), 'Escaping file')
        require(file.stat().st_size == row['bytes'], 'File length mismatch: ' + name)
        with file.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(digest == row['sha256'], 'File digest mismatch: ' + name)
        total += row['bytes']
        require(total <= 4 * 1024**3, 'Expanded size budget exceeded')
    observed = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    require(observed == expected | {'release-manifest.json', 'MANIFEST.sha256'}, 'Unexpected delivery files')
    return {'status': 'PASS', 'source_commit': manifest['source_commit'], 'files': len(expected),
            'bytes': total, 'scope': 'Unmodified byte consistency; not publisher identity or production eligibility'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', nargs='?', default='.')
    print(json.dumps(verify(parser.parse_args().directory), indent=2))
