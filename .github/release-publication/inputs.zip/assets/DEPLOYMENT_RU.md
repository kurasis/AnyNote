# AnyNote: краткое развёртывание

Комплект `0.18.0-review`, исходники `c52af68046f98e55fab904f2f9bfd3984e54498a`.
Windows-приложение имеет фактическую версию **0.14.0** и собрано в release-профиле без
инструментирования UI. Authenticode отсутствует. Это сборка для проверки: независимый
аудит, физические испытания, реальные подписи и лицензирование всего выпуска ещё открыты.

## 1. Проверить комплект

Распакуйте ZIP в новую папку. Из папки с этим файлом выполните:

```sh
python3 verify-release.py .
mkdir -p Source/checkout
tar -xf Source/AnyNote-source.tar -C Source/checkout
```

Проверка SHA-256 подтверждает целостность. Подлинность источника проверяйте отдельно;
контрольная сумма рядом с неизвестной загрузкой не подтверждает издателя.
Для Windows запускается `Windows/AnyNote_0.14.0_x64-setup.exe`.

## 2. Подготовить новый изолированный сервер

Нужны Linux x86_64, Docker с Compose v2, Python 3.12+, Node 24.21.0/npm 11.19.0.
Для полной квоты нужны реальные 100 ГБ шифротекста **плюс** место под БД, рабочие
файлы и резервные копии; эксплуатационный резерв — не менее max(10 GiB, 10%).
Не применяйте эту инструкцию поверх работающего сервиса или существующей БД.

Заведите два разных HTTPS-имени: для API и PWA. Подготовьте DNS, доверенные TLS-сертификаты
для обоих имён и отдельный operator CA для административного mTLS. В примерах ниже
замените `api.vault.example` / `app.vault.example` своими именами.

Загрузите точный образ:

```sh
docker load --input Server/api-image.tar.gz
docker image inspect --format '{{.Id}}' sha256:a90c5349b188e4ea88f5bac244176b15f890ea89e9ab166a555b8111274a1da5
```

Создайте каталоги `/srv/anynote/state/{database,secrets,tls,storage}` и
`/srv/anynote-static/release`. Владелец — отдельный непривилегированный UID/GID,
указанный в конфигурации (пример: 1000:1000). В `storage` нужны `app/private/p16-delivery`,
`framework/cache/data`, `framework/sessions`, `framework/views`, `logs`.
Секретные каталоги и файлы должны быть доступны только назначенным владельцам.

В `state/secrets` установите из защищённого хранилища файлы `app_key`,
`database_password`, `database_root`, `oauth_private`, `oauth_public`.
В `state/tls` — `server.crt`, `server.key`, `operator-ca.crt`.
Не используйте ключи/CA из тестовых стендов. Backup, updater и пользовательские
recovery-ключи хранятся отдельно от runtime; значения секретов не входят в комплект.

Скопируйте `DEPLOYMENT.env.example` в новый `/secure/operator/anynote.env`, установите
режим 0600 и заполните домены, RP ID, независимый service ID, UID/GID, пути и публичный
backup recipient. Привязка HTTPS первоначально оставлена на `127.0.0.1`.

## 3. Подготовить Nginx и PWA

Выполняйте из `Source/checkout`:

```sh
python3 scripts/operations.py --environment /secure/operator/anynote.env render
for project in experiments/p01 packages/protocol apps/devices-web apps/notes-web packages/content-browser; do
  npm --prefix "$project" ci --ignore-scripts --no-audit --no-fund
done
node experiments/p01/node_modules/esbuild/install.js
ANYNOTE_API_ISSUER=https://api.vault.example \
ANYNOTE_STATIC_OUTPUT=/srv/anynote-static/release/auth \
ANYNOTE_STATIC_WORK=/tmp/anynote-static-work \
ANYNOTE_STATIC_POLICY=/srv/anynote/state/nginx.conf \
node experiments/p01/p06-build.mjs
```

API-имя в команде обязано совпадать с конфигурацией. Готовая папка `PWA/auth` в
комплекте содержит точные проверенные тестовые байты для `https://api.anynote.test:18443`.
Для своих доменов нужна указанная сборка и новая проверка полученных статических
байтов. Статическую публикацию и её подпись выполняет отдельный назначенный оператор.

## 4. Инициализировать БД и запустить службы

Из `Source/checkout` задайте функцию для **нового** проекта:

```sh
dc() {
  docker compose --project-name anynote-reviewed-staging \
    --env-file /secure/operator/anynote.env -f infra/operations/compose.yaml "$@"
}
dc config --quiet
dc up -d --wait db
dc run --rm --no-deps -T \
  -v /srv/anynote/state/secrets/database_root:/run/secrets/database_root:ro \
  --entrypoint sh api -c 'export APP_KEY="$(cat /run/secrets/app_key)" DB_PASSWORD="$(cat /run/secrets/database_root)" DB_USERNAME=root; exec php artisan migrate --force --no-interaction'
dc exec -T db sh -c 'export MYSQL_PWD="$(cat /run/secrets/database_root)"; exec mariadb -uroot anynote -e "REVOKE ALL PRIVILEGES ON anynote.* FROM '\''anynote_runtime'\''@'\''%'\''; GRANT SELECT, INSERT, UPDATE, DELETE ON anynote.* TO '\''anynote_runtime'\''@'\''%'\'';"'
dc up -d api queue scheduler edge
dc exec -T edge nginx -t
dc run --rm --no-deps -T api php artisan operations:health
```

Имя проекта функции должно совпадать с `ANYNOTE_PROJECT` в env. Дождитесь `ready`;
при ошибке проверьте закрытые журналы, права каталогов и конфигурацию. Не сбрасывайте БД.
Проверьте настоящие HTTPS-запросы, CORS и шифрованный обмен перед открытием доступа.
Внешний bind/firewall меняется отдельно после этих проверок; БД наружу не публикуется.

## 5. Первый вход и дальнейшая эксплуатация

```sh
dc run --rm --no-deps -T api php artisan accounts:bootstrap-invite
```

Приглашение выводится один раз в приватную консоль оператора. Откройте PWA своего
домена по пути `/auth/`, зарегистрируйтесь по приглашению и подключите Windows-клиент
к тому же API. Пароли и recovery-kit сохраняет пользователь вне сервера.
До эксплуатации проверьте backup/restore, отдельное хранение checkpoint и ключей,
реальную ёмкость, подписи и приёмку. Полные процедуры находятся в исходниках:
`docs/P16_OPERATIONS.md`, `docs/OPERATOR_HANDOFF.md`, `docs/P14_UPDATE_SIGNING.md`.

Исходные проверки этой сборки: 30/30 PR и отдельно 30/30 main.
Доказательства: https://github.com/kurasis/AnyNote/tree/5df3aa7c85fabad8c5b36a2502f733bd0aa47351/docs/evidence/windows-memory/final
