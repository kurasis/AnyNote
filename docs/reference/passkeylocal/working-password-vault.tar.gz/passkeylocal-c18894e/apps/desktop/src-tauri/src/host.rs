use crate::file_safe::{
    commands::*,
    manager::{SafeHost, SafeManager},
};
use crate::{
    filesystem as io, hello,
    inactivity::Inactivity,
    storage::{Error, Result, Store, MAX_BYTES},
};
use serde_json::Value;
use std::{
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, AtomicU64, Ordering},
        mpsc::{self, SyncSender},
        Mutex,
    },
    time::{Duration, Instant},
};
use tauri::{Emitter, Manager, State, WebviewWindow};

struct NativeState {
    store: Mutex<Store>,
    hello: Mutex<hello::enrollment::Manager>,
    hello_serial: AtomicU64,
    active: Mutex<Option<String>>,
    serial: AtomicU64,
    inactivity: Mutex<Inactivity>,
    browser_privacy: AtomicBool,
    backup: SyncSender<()>,
}
impl NativeState {
    fn check(&self, token: &str) -> Result<()> {
        if self
            .active
            .lock()
            .map_err(|_| Error::new("UNAVAILABLE"))?
            .as_deref()
            == Some(token)
            && !self
                .inactivity
                .lock()
                .map_err(|_| Error::new("UNAVAILABLE"))?
                .expired(Instant::now())
        {
            Ok(())
        } else {
            Err(Error::new("INVALID_STATE"))
        }
    }
    fn wake_backup(&self) {
        let _ = self.backup.try_send(());
    }
}
pub(crate) fn trusted(window: &WebviewWindow) -> Result<()> {
    if window.label() != "main" {
        return Err(Error::new("INVALID_STATE"));
    }
    // Capabilities additionally deny remote origins and unknown windows.
    Ok(())
}
pub(crate) fn focused(window: &WebviewWindow) -> Result<()> {
    trusted(window)?;
    if window.is_focused().unwrap_or(false) {
        Ok(())
    } else {
        Err(Error::new("INVALID_STATE"))
    }
}
fn store<'a>(state: &'a State<'_, NativeState>) -> Result<std::sync::MutexGuard<'a, Store>> {
    state.store.lock().map_err(|_| Error::new("UNAVAILABLE"))
}
#[tauri::command]
async fn session_begin(window: WebviewWindow, app: tauri::AppHandle) -> Result<String> {
    trusted(&window)?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<NativeState>();
        let mut storage = store(&state)?;
        let token = storage.begin();
        let mut active = state.active.lock().map_err(|_| Error::new("UNAVAILABLE"))?;
        if serial != state.serial.load(Ordering::SeqCst) {
            storage.end(&token);
            return Err(Error::new("INVALID_STATE"));
        }
        state
            .inactivity
            .lock()
            .map_err(|_| Error::new("UNAVAILABLE"))?
            .begin(Instant::now(), storage.lock_interval());
        *active = Some(token.clone());
        Ok(token)
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn session_end(window: WebviewWindow, app: tauri::AppHandle, token: String) -> Result<()> {
    trusted(&window)?;
    let state = app.state::<NativeState>();
    {
        let mut active = state.active.lock().map_err(|_| Error::new("UNAVAILABLE"))?;
        if active.as_deref() == Some(&token) {
            *active = None;
        }
    }
    tauri::async_runtime::spawn_blocking(move || {
        store(&app.state::<NativeState>())?.end(&token);
        Ok(())
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn storage(
    window: WebviewWindow,
    app: tauri::AppHandle,
    token: String,
    operation: String,
    args: Value,
) -> Result<Value> {
    trusted(&window)?;
    if token.len() > 64 || operation.len() > 64 {
        return Err(Error::new("INVALID_STATE"));
    }
    if args
        .get("bytes")
        .and_then(Value::as_array)
        .is_some_and(|a| a.len() > MAX_BYTES)
    {
        return Err(Error::new("CORRUPT"));
    }
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<NativeState>();
        state.check(&token)?;
        // Invalidate before any credential-changing write; a busy OS prompt
        // makes this write retryable, never lets it race an old unwrap.
        if hello::enrollment::credential_write(&operation, &args) {
            state.hello_serial.fetch_add(1, Ordering::SeqCst);
            let root = app
                .path()
                .app_local_data_dir()
                .map_err(|_| Error::new("UNAVAILABLE"))?;
            let revoked = state.hello.try_lock().map_err(|_| Error::new("BUSY"))?.run(
                &root,
                0,
                &|| true,
                &|| Err(Error::new("INVALID_STATE")),
                &hello::enrollment::Action::Revoke {},
            );
            // The envelope is already durably nonresumable when only native
            // object deletion failed. Password recovery must remain possible;
            // Settings keeps reporting cleanup-required until deletion succeeds.
            if let Err(e) = revoked {
                if e.code != "HELLO_CLEANUP_REQUIRED" {
                    return Err(e);
                }
            }
        }
        let mut managed = store(&state)?;
        state.check(&token)?;
        managed.native_deadline(
            state
                .inactivity
                .lock()
                .map_err(|_| Error::new("UNAVAILABLE"))?
                .deadline(),
        );
        let result = managed.dispatch(&token, &operation, args);
        if result.is_ok() && operation == "setPreference" {
            state
                .inactivity
                .lock()
                .map_err(|_| Error::new("UNAVAILABLE"))?
                .interval(Instant::now(), managed.lock_interval());
        }
        drop(managed);
        if result.is_ok() && ["commit", "restoreBlob"].contains(&operation.as_str()) {
            state.wake_backup();
        }
        result
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
fn native_activity(window: WebviewWindow, state: State<'_, NativeState>) -> Result<()> {
    focused(&window)?;
    state
        .inactivity
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .activity(Instant::now());
    Ok(())
}
#[tauri::command]
async fn native_status(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    trusted(&window)?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<NativeState>();
        let mut status = store(&state)?.status();
        status["browserPrivacyVerified"] =
            Value::Bool(state.browser_privacy.load(Ordering::Acquire));
        Ok(status)
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn pick_import(window: WebviewWindow) -> Result<Option<Vec<u8>>> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    tauri::async_runtime::spawn_blocking(move || {
        let dialog = rfd::FileDialog::new()
            .set_title("Choose encrypted KDBX backup")
            .add_filter("Encrypted vault", &["kdbx"]);
        let parent = WindowParent(hwnd);
        let dialog = dialog.set_parent(&parent);
        dialog
            .pick_file()
            .map(|path| io::read_import(&path))
            .transpose()
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn export_backup(window: WebviewWindow, bytes: Vec<u8>) -> Result<bool> {
    focused(&window)?;
    if bytes.is_empty() || bytes.len() > MAX_BYTES {
        return Err(Error::new("CORRUPT"));
    }
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    tauri::async_runtime::spawn_blocking(move || {
        let parent = WindowParent(hwnd);
        let Some(path) = rfd::FileDialog::new()
            .set_parent(&parent)
            .set_title("Save encrypted backup (choose a new filename)")
            .set_file_name("vault-backup.kdbx")
            .add_filter("Encrypted vault", &["kdbx"])
            .save_file()
        else {
            return Ok(false);
        };
        let path = io::user_path(&path)?;
        let _pins = io::pin_directory(path.parent().ok_or(Error::new("INVALID_STATE"))?)?;
        // Exports never overwrite another backup, even if the OS dialog offers it.
        io::exclusive_write(&path, &bytes)?;
        Ok(true)
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn configure_backup(window: WebviewWindow, app: tauri::AppHandle) -> Result<()> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    tauri::async_runtime::spawn_blocking(move || {
        let parent = WindowParent(hwnd);
        let selected = rfd::FileDialog::new()
            .set_parent(&parent)
            .set_title("Choose an external backup folder")
            .pick_folder();
        if let Some(path) = selected {
            let state = app.state::<NativeState>();
            store(&state)?.configure_backup(&path)?;
            state.wake_backup();
        }
        Ok(())
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
fn retry_backup(window: WebviewWindow, state: State<'_, NativeState>) -> Result<()> {
    focused(&window)?;
    state.wake_backup();
    Ok(())
}
#[tauri::command]
async fn backup_retention(
    window: WebviewWindow,
    app: tauri::AppHandle,
    retention: usize,
) -> Result<()> {
    focused(&window)?;
    tauri::async_runtime::spawn_blocking(move || {
        store(&app.state::<NativeState>())?.set_backup_retention(retention)
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))?
}
#[tauri::command]
async fn hello_status(window: WebviewWindow) -> Result<Value> {
    trusted(&window)?;
    tauri::async_runtime::spawn_blocking(hello::diagnostics::check)
        .await
        .map_err(|_| Error::new("UNAVAILABLE"))
}
#[tauri::command]
async fn hello_verify(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let result = tauri::async_runtime::spawn_blocking(move || hello::diagnostics::verify(hwnd))
        .await
        .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    if app.state::<NativeState>().serial.load(Ordering::SeqCst) != serial {
        return Err(Error::new("CANCELLED"));
    }
    Ok(result)
}
#[tauri::command]
async fn hello_key_proof(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_experiment(window, app, hello::proof::Experiment::SecurityProof).await
}
#[tauri::command]
async fn hello_oaep_capability(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_experiment(
        window,
        app,
        hello::proof::Experiment::AuthorizedOaepCapability,
    )
    .await
}
#[tauri::command]
async fn hello_pkcs1_compatibility(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_experiment(window, app, hello::proof::Experiment::Pkcs1Compatibility).await
}
#[tauri::command]
async fn hello_pkcs1_behavior(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_experiment(window, app, hello::proof::Experiment::Pkcs1Behavior).await
}
#[tauri::command]
async fn hello_attestation_capability(
    window: WebviewWindow,
    app: tauri::AppHandle,
) -> Result<Value> {
    hello_experiment(window, app, hello::proof::Experiment::AttestationCapability).await
}
#[tauri::command]
async fn hello_webauthn_capability(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_prf_experiment(window, app, hello::prf::Experiment::Capability).await
}
#[tauri::command]
async fn hello_prf_proof(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_prf_experiment(window, app, hello::prf::Experiment::Synthetic).await
}
#[tauri::command]
async fn hello_webauthn_attestation(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_prf_experiment(window, app, hello::prf::Experiment::DirectAttestation).await
}
#[tauri::command]
async fn hello_tpm_capability(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_tpm_experiment(window, app, hello::tpm::Experiment::Capability).await
}
#[tauri::command]
async fn hello_tpm_proof(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_tpm_experiment(window, app, hello::tpm::Experiment::Synthetic).await
}
#[tauri::command]
async fn hello_tpm_local_binding(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_tpm_experiment(window, app, hello::tpm::Experiment::LocalBinding).await
}
#[tauri::command]
async fn hello_combined_status(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_combined_experiment(window, app, hello::combined::Action::Status).await
}
#[tauri::command]
async fn hello_combined_prepare(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_combined_experiment(window, app, hello::combined::Action::Prepare).await
}
#[tauri::command]
async fn hello_combined_resume(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_combined_experiment(window, app, hello::combined::Action::Resume).await
}
#[tauri::command]
async fn hello_combined_cleanup(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_combined_experiment(window, app, hello::combined::Action::Cleanup).await
}
#[tauri::command]
async fn hello_combined_key_loss(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_combined_experiment(window, app, hello::combined::Action::KeyLoss).await
}
async fn hello_combined_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    action: hello::combined::Action,
) -> Result<Value> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let root = app
        .path()
        .app_local_data_dir()
        .map_err(|_| Error::new("UNAVAILABLE"))?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let report = tauri::async_runtime::spawn_blocking(move || {
        hello::combined::run(
            &root,
            hwnd,
            || {
                let state = app.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state.active.lock().is_ok_and(|active| *active == session)
            },
            action,
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    serde_json::to_value(report).map_err(|_| Error::new("UNAVAILABLE"))
}

#[tauri::command]
async fn hello_copy_prepare(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_copy_experiment(window, app, hello::combined::copy::Action::PrepareExport).await
}
#[tauri::command]
async fn hello_copy_export(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_copy_experiment(window, app, hello::combined::copy::Action::Export).await
}
#[tauri::command]
async fn hello_copy_check(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    hello_copy_experiment(window, app, hello::combined::copy::Action::Check).await
}
async fn hello_copy_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    action: hello::combined::copy::Action,
) -> Result<Value> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let root = app
        .path()
        .app_local_data_dir()
        .map_err(|_| Error::new("UNAVAILABLE"))?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let report = tauri::async_runtime::spawn_blocking(move || {
        hello::combined::run_copy(
            &root,
            hwnd,
            || {
                let state = app.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state.active.lock().is_ok_and(|active| *active == session)
            },
            action,
            |save| {
                let parent = WindowParent(hwnd);
                let dialog = rfd::FileDialog::new()
                    .set_parent(&parent)
                    .add_filter("Synthetic Hello copy test", &["hello-test"]);
                if save {
                    dialog
                        .set_title("Save a new synthetic Hello copy test")
                        .set_file_name("PassKeyLocal-copy.hello-test")
                        .save_file()
                } else {
                    dialog
                        .set_title("Check a synthetic Hello copy test (read only)")
                        .pick_file()
                }
            },
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    serde_json::to_value(report).map_err(|_| Error::new("UNAVAILABLE"))
}

#[tauri::command]
async fn hello_recovery_prepare(window: WebviewWindow, app: tauri::AppHandle) -> Result<Value> {
    focused(&window)?;
    hello_recovery_experiment(window, app, hello::combined::recovery::Action::Prepare).await
}
#[tauri::command]
async fn hello_recovery_revoke(
    window: WebviewWindow,
    app: tauri::AppHandle,
    ticket: String,
) -> Result<Value> {
    // Automatic disposal must still work after focus/session loss. Only the exact
    // current-process synthetic journal ticket can be revoked by this command.
    trusted(&window)?;
    if ticket.len() != 36 {
        return Err(Error::new("INVALID_STATE"));
    }
    hello_recovery_experiment(
        window,
        app,
        hello::combined::recovery::Action::Revoke(ticket),
    )
    .await
}
async fn hello_recovery_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    action: hello::combined::recovery::Action,
) -> Result<Value> {
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let root = app
        .path()
        .app_local_data_dir()
        .map_err(|_| Error::new("UNAVAILABLE"))?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let owner = app.clone();
    let current_session = session.clone();
    let mut reply = tauri::async_runtime::spawn_blocking(move || {
        hello::combined::run_recovery(
            &root,
            hwnd,
            || {
                let state = owner.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state
                        .active
                        .lock()
                        .is_ok_and(|active| *active == current_session)
            },
            action,
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    let state = app.state::<NativeState>();
    if state.serial.load(Ordering::SeqCst) != serial
        || !state.active.lock().is_ok_and(|active| *active == session)
    {
        reply.redact();
    }
    serde_json::to_value(&reply).map_err(|_| Error::new("UNAVAILABLE"))
}

async fn hello_tpm_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    experiment: hello::tpm::Experiment,
) -> Result<Value> {
    focused(&window)?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let report = tauri::async_runtime::spawn_blocking(move || {
        hello::tpm::run(
            || {
                let state = app.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state.active.lock().is_ok_and(|active| *active == session)
            },
            experiment,
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    serde_json::to_value(report).map_err(|_| Error::new("UNAVAILABLE"))
}
async fn hello_prf_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    experiment: hello::prf::Experiment,
) -> Result<Value> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let report = tauri::async_runtime::spawn_blocking(move || {
        hello::prf::run(
            hwnd,
            || {
                let state = app.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state.active.lock().is_ok_and(|active| *active == session)
            },
            experiment,
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    trusted(&window)?;
    serde_json::to_value(report).map_err(|_| Error::new("UNAVAILABLE"))
}
async fn hello_experiment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    experiment: hello::proof::Experiment,
) -> Result<Value> {
    focused(&window)?;
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    let session = app
        .state::<NativeState>()
        .active
        .lock()
        .map_err(|_| Error::new("UNAVAILABLE"))?
        .clone();
    let report = tauri::async_runtime::spawn_blocking(move || {
        hello::proof::run(
            hwnd,
            || {
                let state = app.state::<NativeState>();
                state.serial.load(Ordering::SeqCst) == serial
                    && state.active.lock().is_ok_and(|active| *active == session)
            },
            experiment,
        )
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    // The report has no secret or usable credential. Returning interruption
    // and deletion evidence is safe even when a lock changed the generation.
    trusted(&window)?;
    serde_json::to_value(report).map_err(|_| Error::new("UNAVAILABLE"))
}
#[tauri::command]
fn hello_settings(window: WebviewWindow) -> Result<()> {
    focused(&window)?;
    // A fixed OS destination, never a caller-supplied protocol or command.
    use windows_sys::Win32::UI::{Shell::ShellExecuteW, WindowsAndMessaging::SW_SHOWNORMAL};
    let target: Vec<_> = "ms-settings:signinoptions"
        .encode_utf16()
        .chain(Some(0))
        .collect();
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0;
    let result = unsafe {
        ShellExecuteW(
            hwnd,
            std::ptr::null(),
            target.as_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            SW_SHOWNORMAL,
        )
    };
    if result as usize <= 32 {
        Err(Error::new("UNAVAILABLE"))
    } else {
        Ok(())
    }
}
#[tauri::command]
async fn hello_enrollment(
    window: WebviewWindow,
    app: tauri::AppHandle,
    token: String,
    request: hello::enrollment::Action,
) -> Result<Value> {
    use hello::enrollment::Action;
    if matches!(request, Action::Enroll { .. } | Action::Unlock {}) {
        focused(&window)?;
    } else {
        trusted(&window)?;
    }
    if token.len() > 64 {
        return Err(Error::new("INVALID_STATE"));
    }
    let hwnd = window.hwnd().map_err(|_| Error::new("UNAVAILABLE"))?.0 as usize;
    let root = app
        .path()
        .app_local_data_dir()
        .map_err(|_| Error::new("UNAVAILABLE"))?;
    let serial = app.state::<NativeState>().serial.load(Ordering::SeqCst);
    if matches!(request, Action::Revoke {}) {
        app.state::<NativeState>()
            .hello_serial
            .fetch_add(1, Ordering::SeqCst);
    }
    let hello_serial = app
        .state::<NativeState>()
        .hello_serial
        .load(Ordering::SeqCst);
    let owner = app.clone();
    let session = token.clone();
    let reply = tauri::async_runtime::spawn_blocking(move || {
        let state = owner.state::<NativeState>();
        let current = || {
            state.serial.load(Ordering::SeqCst) == serial
                && state.hello_serial.load(Ordering::SeqCst) == hello_serial
                && state.check(&session).is_ok()
        };
        if !current() {
            return Err(Error::new("STALE"));
        }
        let context = || {
            if !current() {
                return Err(Error::new("STALE"));
            }
            let binding = store(&state)?.hello_binding()?;
            Ok((binding, chrono::Utc::now().timestamp_millis()))
        };
        let result = if matches!(request, Action::Revoke {}) {
            state
                .hello
                .lock()
                .map_err(|_| Error::new("UNAVAILABLE"))?
                .run(&root, hwnd, &current, &context, &request)
        } else {
            state
                .hello
                .try_lock()
                .map_err(|_| Error::new("BUSY"))?
                .run(&root, hwnd, &current, &context, &request)
        };
        result
    })
    .await
    .map_err(|_| Error::new("UNAVAILABLE"))??;
    let state = app.state::<NativeState>();
    if state.serial.load(Ordering::SeqCst) != serial
        || state.hello_serial.load(Ordering::SeqCst) != hello_serial
        || state.check(&token).is_err()
    {
        return Err(Error::new("STALE"));
    }
    serde_json::to_value(&reply).map_err(|_| Error::new("UNAVAILABLE"))
}

#[tauri::command]
fn hello_enroll(window: WebviewWindow) -> Result<Value> {
    focused(&window)?;
    hello::enroll()
}
#[tauri::command]
fn hello_unlock(window: WebviewWindow) -> Result<Value> {
    focused(&window)?;
    hello::unlock()
}
#[tauri::command]
fn hello_revoke(window: WebviewWindow) -> Result<Value> {
    focused(&window)?;
    hello::revoke()
}
#[tauri::command]
fn open_external(window: WebviewWindow, url: String) -> Result<()> {
    focused(&window)?;
    if url.len() > 4096 {
        return Err(Error::new("INVALID_STATE"));
    }
    let parsed = tauri::Url::parse(&url).map_err(|_| Error::new("INVALID_STATE"))?;
    if parsed.scheme() != "https"
        || !parsed.username().is_empty()
        || parsed.password().is_some()
        || parsed.host_str().is_none()
    {
        return Err(Error::new("INVALID_STATE"));
    }
    use windows_sys::Win32::UI::{Shell::ShellExecuteW, WindowsAndMessaging::SW_SHOWNORMAL};
    let verb: Vec<_> = "open".encode_utf16().chain(Some(0)).collect();
    let target: Vec<_> = parsed.as_str().encode_utf16().chain(Some(0)).collect();
    let result = unsafe {
        ShellExecuteW(
            std::ptr::null_mut(),
            verb.as_ptr(),
            target.as_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            SW_SHOWNORMAL,
        )
    };
    if result as usize <= 32 {
        Err(Error::new("UNAVAILABLE"))
    } else {
        Ok(())
    }
}

// Only HWND identity crosses into the blocking picker thread. It is not IPC.
pub(crate) struct WindowParent(pub(crate) usize);
impl raw_window_handle::HasWindowHandle for WindowParent {
    fn window_handle(
        &self,
    ) -> std::result::Result<raw_window_handle::WindowHandle<'_>, raw_window_handle::HandleError>
    {
        let raw = raw_window_handle::Win32WindowHandle::new(
            std::num::NonZeroIsize::new(self.0 as isize)
                .ok_or(raw_window_handle::HandleError::Unavailable)?,
        );
        Ok(unsafe {
            raw_window_handle::WindowHandle::borrow_raw(raw_window_handle::RawWindowHandle::Win32(
                raw,
            ))
        })
    }
}
impl raw_window_handle::HasDisplayHandle for WindowParent {
    fn display_handle(
        &self,
    ) -> std::result::Result<raw_window_handle::DisplayHandle<'_>, raw_window_handle::HandleError>
    {
        Ok(raw_window_handle::DisplayHandle::windows())
    }
}

pub(crate) fn lock_native(app: &tauri::AppHandle) {
    if let Ok(safe) = app.state::<SafeHost>().get() {
        safe.revoke();
    }
    let _ = app.emit_to("main", "file-safe-lock", ());
    let state = app.state::<NativeState>();
    if let Ok(mut active) = state.active.lock() {
        state.serial.fetch_add(1, Ordering::SeqCst);
        *active = None;
    }
    // No filesystem mutex is needed to revoke access/redact immediately.
    // Already-authorized ciphertext writes may finish without revealing UI.
    let _ = app.emit_to("main", "native-lock", ());
    let cleanup_app = app.clone();
    tauri::async_runtime::spawn_blocking(move || {
        if let Ok(safe) = cleanup_app.state::<SafeHost>().get() {
            safe.dispose_locked();
        }
    });
}

fn navigation_allowed(url: &tauri::Url, development: bool) -> bool {
    if !url.username().is_empty() || url.password().is_some() {
        return false;
    }
    let packaged =
        url.port().is_none() && url.host_str() == Some("localhost") && url.scheme() == "tauri"
            || url.port().is_none()
                && url.host_str() == Some("tauri.localhost")
                && url.scheme() == "http";
    packaged
        || development
            && url.scheme() == "http"
            && url.host_str() == Some("localhost")
            && url.port() == Some(1420)
}

unsafe extern "system" fn windows_events(
    hwnd: windows_sys::Win32::Foundation::HWND,
    message: u32,
    wparam: usize,
    lparam: isize,
    _subclass: usize,
    data: usize,
) -> isize {
    use windows_sys::Win32::UI::{
        Shell::{DefSubclassProc, RemoveWindowSubclass},
        WindowsAndMessaging::{WM_NCDESTROY, WM_POWERBROADCAST, WM_WTSSESSION_CHANGE},
    };
    let app = &*(data as *const tauri::AppHandle);
    // Lock, logoff, user switching/disconnect and *all* suspend/resume changes
    // invalidate native tokens before notifying the renderer.
    if message == WM_WTSSESSION_CHANGE
        || message == WM_POWERBROADCAST && [4, 7, 18].contains(&wparam)
    {
        lock_native(app);
    }
    if message == WM_NCDESTROY {
        RemoveWindowSubclass(hwnd, Some(windows_events), 1);
        windows_sys::Win32::System::RemoteDesktop::WTSUnRegisterSessionNotification(hwnd);
        drop(Box::from_raw(data as *mut tauri::AppHandle));
    }
    DefSubclassProc(hwnd, message, wparam, lparam)
}

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _, _| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }))
        .invoke_handler(tauri::generate_handler![
            session_begin,
            session_end,
            storage,
            native_activity,
            native_status,
            pick_import,
            export_backup,
            configure_backup,
            retry_backup,
            backup_retention,
            open_external,
            hello_enrollment,
            hello_enroll,
            hello_status,
            hello_verify,
            hello_key_proof,
            hello_oaep_capability,
            hello_pkcs1_compatibility,
            hello_pkcs1_behavior,
            hello_attestation_capability,
            hello_webauthn_capability,
            hello_prf_proof,
            hello_webauthn_attestation,
            hello_tpm_capability,
            hello_tpm_proof,
            hello_tpm_local_binding,
            hello_combined_status,
            hello_combined_prepare,
            hello_combined_resume,
            hello_combined_cleanup,
            hello_combined_key_loss,
            hello_copy_prepare,
            hello_copy_export,
            hello_copy_check,
            hello_recovery_prepare,
            hello_recovery_revoke,
            hello_settings,
            hello_unlock,
            hello_revoke,
            file_safe_status,
            file_safe_access,
            file_safe_lock,
            lock_all,
            file_safe_activity,
            file_safe_interval,
            file_safe_page,
            file_safe_change,
            file_safe_import,
            file_safe_cancel,
            file_safe_export,
            file_safe_rotate,
            file_safe_backup,
            file_safe_recover,
            file_safe_retry_backup,
            file_safe_import_results
        ])
        .setup(|app| {
            let root: PathBuf = app.path().app_local_data_dir()?;
            // Keep Chromium profile files and its sandbox permissions outside
            // the protected ciphertext-only managed directory.
            let browser_profile = root.with_file_name("com.passkeylocal.vault-webview");
            io::reject_links(&browser_profile).map_err(|e| std::io::Error::other(e.code))?;
            let state = Store::open(&root).map_err(|e| std::io::Error::other(e.code))?;
            let inactivity = Inactivity::new(state.lock_interval());
            let safe_root = root.with_file_name("com.passkeylocal.file-safe");
            let safe_manager = match SafeManager::open(&safe_root) {
                Ok(safe) => Some(std::sync::Arc::new(safe)),
                Err(_) => {
                    eprintln!(
                        "File-safe service unavailable; password-vault access remains available"
                    );
                    None
                }
            };
            app.manage(SafeHost {
                manager: safe_manager,
            });
            let safe_backup_app = app.handle().clone();
            std::thread::spawn(move || loop {
                std::thread::sleep(Duration::from_secs(1));
                if let Ok(safe) = safe_backup_app.state::<SafeHost>().get() {
                    safe.backups.run_due();
                }
            });
            let (wake, jobs) = mpsc::sync_channel(1);
            app.manage(NativeState {
                hello: Mutex::new(hello::enrollment::Manager::default()),
                hello_serial: AtomicU64::new(0),
                store: Mutex::new(state),
                active: Mutex::new(None),
                serial: AtomicU64::new(0),
                inactivity: Mutex::new(inactivity),
                browser_privacy: AtomicBool::new(false),
                backup: wake,
            });
            let backup_app = app.handle().clone();
            std::thread::spawn(move || loop {
                let _ = jobs.recv_timeout(Duration::from_secs(30));
                let state = backup_app.state::<NativeState>();
                let job = state
                    .store
                    .lock()
                    .ok()
                    .and_then(|s| s.pending_backup().ok().flatten());
                if let Some(job) = job {
                    let outcome = job.run(); // external I/O without the vault lock
                    if let Ok(mut s) = state.store.lock() {
                        let _ = s.finish_backup(&job, outcome);
                    }
                }
            });
            let config = app
                .config()
                .app
                .windows
                .first()
                .ok_or("main window configuration unavailable")?;
            let window = tauri::WebviewWindowBuilder::from_config(app, config)?
                .data_directory(browser_profile)
                .general_autofill_enabled(false)
                .on_navigation(|url| {
                    // Initial packaged load and dev server only. No record URL
                    // can navigate the privileged WebView or open a popup.
                    navigation_allowed(url, cfg!(debug_assertions))
                })
                .on_new_window(|_, _| tauri::webview::NewWindowResponse::Deny)
                .build()?;
            // Show only after disabling and reading back password saving and
            // autofill, so WebView2 cannot persist master/entry form values.
            let privacy_window = window.clone();
            let privacy_app = app.handle().clone();
            window.with_webview(move |platform| {
                use webview2_com::Microsoft::Web::WebView2::Win32::ICoreWebView2Settings4;
                use windows_core::{Interface, BOOL};
                let configured = unsafe {
                    (|| -> windows_core::Result<bool> {
                        let settings = platform
                            .controller()
                            .CoreWebView2()?
                            .Settings()?
                            .cast::<ICoreWebView2Settings4>()?;
                        settings.SetIsPasswordAutosaveEnabled(false)?;
                        settings.SetIsGeneralAutofillEnabled(false)?;
                        let mut password = BOOL(1);
                        let mut autofill = BOOL(1);
                        settings.IsPasswordAutosaveEnabled(&mut password)?;
                        settings.IsGeneralAutofillEnabled(&mut autofill)?;
                        Ok(!password.as_bool() && !autofill.as_bool())
                    })()
                    .unwrap_or(false)
                };
                if !configured {
                    eprintln!("WebView2 privacy settings unavailable; vault window stays closed");
                    privacy_app.exit(1);
                    return;
                }
                privacy_app
                    .state::<NativeState>()
                    .browser_privacy
                    .store(true, Ordering::Release);
                if privacy_window.show().is_err() {
                    privacy_app.exit(1);
                    return;
                }
                let _ = privacy_window.set_focus();
            })?;
            let hwnd = window.hwnd()?;
            let pointer = Box::into_raw(Box::new(app.handle().clone()));
            unsafe {
                use windows_sys::Win32::{
                    System::RemoteDesktop::{
                        WTSRegisterSessionNotification, NOTIFY_FOR_THIS_SESSION,
                    },
                    UI::Shell::SetWindowSubclass,
                };
                if SetWindowSubclass(hwnd.0 as _, Some(windows_events), 1, pointer as usize) == 0 {
                    drop(Box::from_raw(pointer));
                    return Err("Windows lifecycle hook unavailable".into());
                }
                if WTSRegisterSessionNotification(hwnd.0 as _, NOTIFY_FOR_THIS_SESSION) == 0 {
                    return Err("Windows session notifications unavailable".into());
                }
            }
            let timer_app = app.handle().clone();
            std::thread::spawn(move || loop {
                std::thread::sleep(Duration::from_secs(1));
                if let Ok(safe) = timer_app.state::<SafeHost>().get() {
                    if safe.expire() {
                        let _ = timer_app.emit_to("main", "file-safe-lock", ());
                    }
                    safe.dispose_locked();
                }
                let state = timer_app.state::<NativeState>();
                // Match begin/check lock order and revoke under the same guard;
                // an old timeout observation cannot revoke a newer session.
                let revoked = if let Ok(mut active) = state.active.lock() {
                    let expired = state
                        .inactivity
                        .lock()
                        .map(|s| s.expired(Instant::now()))
                        .unwrap_or(true);
                    if active.is_some() && expired {
                        state.serial.fetch_add(1, Ordering::SeqCst);
                        *active = None;
                        true
                    } else {
                        false
                    }
                } else {
                    true
                };
                if revoked {
                    let _ = timer_app.emit_to("main", "native-lock", ());
                }
            });
            app.state::<NativeState>().wake_backup();
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("PassKey Local desktop could not start");
}

#[cfg(test)]
mod tests {
    use super::navigation_allowed;
    #[test]
    fn navigation_rejects_other_ports_credentials_and_remote_origins() {
        for input in [
            "tauri://localhost/index.html",
            "http://tauri.localhost/index.html",
        ] {
            assert!(navigation_allowed(
                &tauri::Url::parse(input).unwrap(),
                false
            ));
        }
        for input in [
            "http://tauri.localhost:9090/",
            "tauri://localhost:9090/",
            "http://user@tauri.localhost/",
            "http://tauri.localhost.evil.example/",
            "https://tauri.localhost/",
            "https://example.com/",
            "file:///C:/vault.kdbx",
            "data:text/html,hello",
            "http://localhost:1420/",
        ] {
            assert!(
                !navigation_allowed(&tauri::Url::parse(input).unwrap(), false),
                "{input}"
            );
        }
        assert!(navigation_allowed(
            &tauri::Url::parse("http://localhost:1420/").unwrap(),
            true
        ));
        assert!(!navigation_allowed(
            &tauri::Url::parse("http://localhost:1421/").unwrap(),
            true
        ));
    }
}
